## Global functions
- send_message_broadcast(string)
- encode_json(table)
- encode_json_pretty(table)
- decode_json(string)
